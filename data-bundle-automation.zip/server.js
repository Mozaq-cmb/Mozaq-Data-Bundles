const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");
require("dotenv").config();

const app = express();
app.use(bodyParser.json());

// Test endpoint
app.get("/", (req, res) => {
    res.send("Data Bundle Automation API Running");
});

// M-Pesa callback endpoint
app.post("/mpesa-callback", async (req, res) => {
    const { phone, amount, bundle } = req.body;
    console.log(`Payment received: ${phone} paid Ksh ${amount} for ${bundle}`);

    try {
        // Call Bingwa Sokoni API
        const response = await axios.post("https://bingwa-sokoni-api.com/api/v1/buy-bundle", {
            phone,
            bundle
        }, {
            headers: {
                Authorization: `Bearer ${process.env.BINGWA_API_KEY}`
            }
        });

        console.log("Bundle sent successfully:", response.data);
        res.status(200).send({ success: true, message: "Bundle sent" });
    } catch (error) {
        console.error("Error purchasing bundle:", error.message);
        res.status(500).send({ success: false, error: error.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
