# Data Bundle Automation (M-Pesa + Bingwa Sokoni)

This repository is a starter template for automating data bundle sales using:
- M-Pesa Daraja API (for payments)
- Bingwa Sokoni API (for bundle delivery)

## How It Works
1. Customer pays via M-Pesa Till Number.
2. Daraja API sends payment confirmation to /mpesa-callback endpoint.
3. The system calls Bingwa Sokoni API to send the bundle.

## Setup
1. Install dependencies: `npm install`
2. Add your Bingwa Sokoni API key and Till number in `.env`
3. Run locally: `node server.js`
4. Deploy to any server (e.g., Render, Railway, or AWS).

## Contact
Suntree Sola Tech Company
Phone: 0795568595 | 0720455678
